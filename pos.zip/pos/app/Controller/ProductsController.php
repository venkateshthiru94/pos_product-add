
<?php
class ProductsController extends Controller {


public function index() {

$product = $this->Product->find('all');

//echo '<pre>';print_r($product);exit;
    $this->set('products', $product);
}


  public function add()
  {
   
    $uploadData = '';
    if(!empty($this->request->data))
    {
        $total = count($this->request->data['Product']['files']);
        for($i=0;$i<$total;$i++)
        {
             $this->Product->create();
           /* print_r($this->request->data['User']['files'][$i]);*/
            $name = $this->request->data['Product']['files'][$i]['name'];
            $tmprary_name = $this->request->data['Product']['files'][$i]['tmp_name'];
            $temp = explode(".", $name);      
            $newfilename = uniqid(). '.' . end($temp);
            $target_dir='../../app/webroot/img/uploads/';
              if (move_uploaded_file($tmprary_name , $target_dir.$newfilename))
               {
                    echo "The file ". basename( $name). " has been successfully uploaded.<BR/>";
                    $uploadData= $target_dir.$newfilename;
                    //$this->request->data['User']['image'] =$name;
                    //$this->request->data['User']['file_path'] =$uploadData;
                    //$this->User->save($this->request->data);
                    //$status="1";     
                   // Code for comma separated
                   $comma_name[]= $name;   
                   $comma_path[] = $uploadData;
                 }
                 else 
                 {
                    $status="0";   
                   echo "Sorry, there was an error uploading your file.<br/>";
                 }
                   
             
        }   
// Code for comma separated
    $separated_name=implode(",", $comma_name);
    $separated_path=implode(",", $comma_path);
   
     $this->request->data['Product']['image'] =$separated_name;
     $this->request->data['Product']['file_path'] =$separated_path;
        

        //echo "<pre>";print_r($this->request->data);exit;
 
                     if ( $this->Product->save($this->request->data))
                   {

                        $this->Session->setFlash('Product Added Successfully.');
                                
                        $this->redirect(array('action' => 'index'));                            
                    }
                    else
                    {
                                
                        $this->Session->setFlash('Unable to add product. Please, try again.');
                                 
                    } 


                    // code for line item
              /*  if ($status=="1")
                   {

                        $this->Session->setFlash('Product Added Successfully.');
                                
                        $this->redirect(array('action' => 'index'));                            
                    }
                    else
                    {
                                
                        $this->Session->setFlash('Unable to add product. Please, try again.');
                                 
                    } */
}
}


public function edit() {
    
    $id = $this->request->params['pass'][0];
     
    
    $this->Product->id = $id;
     
    
    if( $this->Product->exists() ){
     
        if( $this->request->is( 'post' ) || $this->request->is( 'put' ) ){
           
            if( $this->Product->save( $this->request->data ) ){
             
                
                $this->Session->setFlash('Product was edited.');
                 
                
                $this->redirect(array('action' => 'index'));
                 
            }else{
                $this->Session->setFlash('Unable to edit product. Please, try again.');
            }
             
        }else{
         
            
            $this->request->data = $this->Product->read();
        }
         
    }else{
        

        $this->Session->setFlash('The Product you are trying to edit does not exist.');
        $this->redirect(array('action' => 'index'));
             

    }
}

public function delete() {
    $id = $this->request->params['pass'][0];
     
    if( $this->request->is('get') ){
     
        $this->Session->setFlash('Delete method is not allowed.');
        $this->redirect(array('action' => 'index'));
         
    }else{
     
        if( !$id ) {
            $this->Session->setFlash('Invalid id for product');
            $this->redirect(array('action'=>'index'));
             
        }else{
            
            if( $this->Product->delete( $id ) ){
                
                $this->Session->setFlash('Product was deleted.');
               
                $this->redirect(array('action'=>'index'));
                 
            }else{  
                
                $this->Session->setFlash('Unable to delete product.');
                $this->redirect(array('action' => 'index'));
            }
        }
    }
}
/*public function login(){
    if($this->request->is('post')){
        if($this-Auth->login())
        {
            $this->redirect($this->Auth->redirect());
        }else{
            $this->Session->setFlash('Your username/password combination was incorrect');
        }
    }
}

public function logout(){
    $this->redirect($this->Auth->logout());
} */  
}


?>