<?php

class Product extends AppModel {
    
    var $name = 'Product';
    
    var $validate=array(
            'name' => array(
                'rule3' => array(
                    'rule' => array('between',4,15) ,
                    'message' =>'LANG_MUST_BE_BETWEEN_4_TO_5_CHARACTERS'
                ) ,               
                'rule2' => array(
                    'rule' => array(
                        'custom',
                        '/^[a-zA-Z]/'
                    ) ,
                    'message' => 'LANG_MUST_START_WITH_ALPHABETS'
                ) ,
                'rule1' => array(
                    'rule' => 'notempty',
                    'message' => 'LANG_PLEASE_ENTER_YOUR_NAME'
                ),
            )
        );
            /*'sku'=>array(
            'rule'=>'notempty',
            'message'=>'LANG_PLEASE_ENTER_SKU'
            ),
            'short_description'=>array(
            'rule'=>'notempty',
            'message'=>'LANG_PLEASE_ENTER_SHORT_DESCRIPTION'
            ),
            'description'=>array(
            'rule'=>'notempty',
            'message'=>'LANG_PLEASE_ENTER_DESCRIPTION'
            ),
            'price'=>array(
            'rule'=>'notempty',
            'message'=>'LANG_PLEASE_ENTER_PRICE'
            ),
            'status'=>array(
            'rule'=>'notempty',
            'message'=>'LANG_PLEASE_SELECT_STATUS'
            ),
            'files'=>array(
            'rule'=>'notempty',
            'message'=>'LANG_PLEASE_SELECT_IMAGES'
            ),
        );*/
       
    
}

?>